<?php 

session_start();

?>
<!doctype html>
<html>

<head><title>passenger_info.php</title>

<!--  <link rel="stylesheet" type="text/css" href="../assess/css/style.css">
<link href="https://fonts.googleapis.com/css?family=Nova+Oval" rel="stylesheet">
-->
</head>

<?php

//require 'pnr.php';


?>

<!-- img src="https://api.qrserver.com/v1/create-qr-code/?data='<?php //echo $pnr; ?>' &amp;size=100x100" alt="QRCODE" title="" />


-->







</html>
 

		
		
		
		
		
		
		
		